package com.example.ex4;
// The observer.
public interface Observer {
    // Updates the flight information.
    void UpdateInformation(Information information);
}
